import { FadeLoader } from "react-spinners";

export default function Spinner() {
  return <>
    <FadeLoader color="#d66b36"  />
  </>
}