import Link from 'next/link';
import { FaFacebook, FaTwitter, FaInstagram, FaYoutube, FaWhatsapp } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="py-6 bg-white text-black"> {/* White background, black text */}
      <div className="container mx-auto flex justify-between items-center flex-wrap">
        {/* Social Links */}
        <div className="flex space-x-4">
          <Link href="https://www.facebook.com/yourfacebook" target="_blank">
            <FaFacebook className="text-2xl hover:text-gray-600" /> {/* Hover effect */}
          </Link>
          <Link href="https://www.twitter.com/yourtwitter" target="_blank">
            <FaTwitter className="text-2xl hover:text-gray-600" />
          </Link>
          <Link href="https://www.instagram.com/yourinstagram" target="_blank">
            <FaInstagram className="text-2xl hover:text-gray-600" />
          </Link>
          <Link href="https://www.youtube.com/@yourchannel" target="_blank">
            <FaYoutube className="text-2xl hover:text-gray-600" />
          </Link>
          <Link href="https://wa.me/1234567890" target="_blank">
            <FaWhatsapp className="text-2xl hover:text-gray-600" />
          </Link>
        </div>

        {/* Copyright */}
        <div>
          © {new Date().getFullYear()} Sonar Bangla Nursery. All Rights Reserved.
        </div>

        {/* Additional Links */}
        <div className="flex space-x-4">
          <Link href="/about-us" className="hover:text-gray-600">About Us</Link>
          <Link href="/contact" className="hover:text-gray-600">Contact</Link>
          <Link href="/privacy-policy" className="hover:text-gray-600">Privacy Policy</Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
